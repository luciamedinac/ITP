#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 17 12:41:04 2023

@author: gmarlton
"""

import numpy as np
from scipy import constants, optimize
from pyproj import geod

# Load the node config dictionary this contains information about the nodes
# (receivers) position and name
node_config = np.load("node_config.npy", allow_pickle=True).item()

# Now load in waveforms
waveforms = np.load("exported_waveforms.npy", allow_pickle=True).item()

# For each waveform the following variables are available
# envelope      : The magnitude of the waveform envelope with time
# FT            : The Fast fourier transform of samples
# FT_recon      : The Fast fourire transform of the reconstructed time series
# node_unique_id: A 17 character unique identifier for a node
# peak_index    : The index in the raw data stream that the peak in envelope resides
# prod_time     : The time the waveform was extracted
# raw_data      : The raw time series the waveform was extracted from that has been high pass filtered at 1kHz
# recon_data    : The reconstructed complex time series the waveform was extracted from same as reconstructed samples
# samples       : The real part of extracted waveform
# site_name     : Name of site waveform was recorded at
# t1            : The sum of samples ^ 2
# tdv_penalty   : A time difference variance penalty 
# timestamp     : np.datetime64 object which contains the timestamp at index 256 of samples, envelope, raw_data and recon_data

# The sampling resolution of LEELA is 9.142 us


